# LiftMeUp

## Code Organization: